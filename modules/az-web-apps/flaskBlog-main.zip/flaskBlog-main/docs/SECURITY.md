# Security Policy

**English** | [Türkçe](/docs/SECURITY_TR.md)

Use latest version on [dogukanurker/flaskblog](https://github.com/DogukanUrker/flaskBlog)

## Reporting a Vulnerability

contact: dogukanurker@icloud.com
