# Güvenlik Politikası

[English](./SECURITY.md) | **Türkçe**

[dogukanurker/flaskblog](https://github.com/DogukanUrker/flaskBlog) adresindeki en son sürümü kullanın

## Güvenlik Açığı Bildirme

İletişim: dogukanurker@icloud.com
