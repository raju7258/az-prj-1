[![GitHub Release](<https://img.shields.io/github/v/release/dogukanurker/flaskblog?display_name=release&style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)&link=https%3A%2F%2Fgithub.com%2FDogukanUrker%2FflaskBlog%2Freleases>)](https://github.com/DogukanUrker/flaskBlog/releases)
[![GitHub License](<https://img.shields.io/github/license/dogukanurker/flaskblog?style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)&link=https%3A%2F%2Fgithub.com%2FDogukanUrker%2FflaskBlog%2Fblob%2Fmain%2FLICENSE>)](https://github.com/DogukanUrker/flaskBlog/blob/main/LICENSE)
[![GitHub Repo stars](<https://img.shields.io/github/stars/dogukanurker/flaskblog?style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)&link=https%3A%2F%2Fgithub.com%2FDogukanUrker%2FflaskBlog%2Fstargazers>)](https://github.com/DogukanUrker/flaskBlog/stargazers)
[![GitHub forks](<https://img.shields.io/github/forks/dogukanurker/flaskblog?style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)&link=https%3A%2F%2Fgithub.com%2FDogukanUrker%2FflaskBlog%2Fforks>)](https://github.com/DogukanUrker/flaskBlog/forks)
[![GitHub commit activity](<https://img.shields.io/github/commit-activity/t/dogukanurker/flaskblog?style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)&link=https%3A%2F%2Fgithub.com%2FDogukanUrker%2FflaskBlog%2Fcommits%2Fmain%2F>)](https://github.com/DogukanUrker/flaskBlog/commits/main/)
[![GitHub contributors](<https://img.shields.io/github/contributors/dogukanurker/flaskblog?style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)&link=https%3A%2F%2Fgithub.com%2FDogukanUrker%2FflaskBlog%2Fgraphs%2Fcontributors>)](https://github.com/DogukanUrker/flaskBlog/graphs/contributors)
[![GitHub last commit (branch)](<https://img.shields.io/github/last-commit/dogukanurker/flaskblog/main?style=flat&logoColor=rgb(250%20250%20250)&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)&link=https%3A%2F%2Fgithub.com%2FDogukanUrker%2FflaskBlog%2Fcommits%2Fmain%2F>)](https://github.com/DogukanUrker/flaskBlog/commits/main/)
![GitHub commits since latest release](<https://img.shields.io/github/commits-since/dogukanurker/flaskblog/latest?style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)>)
[![GitHub issues](<https://img.shields.io/github/issues/dogukanurker/flaskblog?style=flat&logoColor=rgb(24%2024%2027)&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)&link=https%3A%2F%2Fgithub.com%2FDogukanUrker%2FflaskBlog%2Fissues>)](https://github.com/DogukanUrker/flaskBlog/issues)
[![GitHub closed issues](<https://img.shields.io/github/issues-closed/dogukanurker/flaskblog?style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)&link=https%3A%2F%2Fgithub.com%2FDogukanUrker%2FflaskBlog%2Fissues%3Fq%3Dis%253Aissue%2Bis%253Aclosed>)](https://github.com/DogukanUrker/flaskBlog/issues?q=is%3Aissue+is%3Aclosed)
[![GitHub pull requests](<https://img.shields.io/github/issues-pr/dogukanurker/flaskblog?style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)&link=https%3A%2F%2Fgithub.com%2FDogukanUrker%2FflaskBlog%2Fpulls>)](https://github.com/DogukanUrker/flaskBlog/pulls)
[![GitHub closed pull requests](<https://img.shields.io/github/issues-pr-closed/dogukanurker/flaskblog?style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)&link=https%3A%2F%2Fgithub.com%2FDogukanUrker%2FflaskBlog%2Fpulls%3Fq%3Dis%253Apr%2Bis%253Aclosed>)](https://github.com/DogukanUrker/flaskBlog/pulls?q=is%3Apr+is%3Aclosed)
[![GitHub watchers](<https://img.shields.io/github/watchers/dogukanurker/flaskblog?style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)&link=https%3A%2F%2Fgithub.com%2FDogukanUrker%2FflaskBlog%2Fwatchers>)](https://github.com/DogukanUrker/flaskBlog/watchers)
![GitHub language count](<https://img.shields.io/github/languages/count/dogukanurker/flaskblog?style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)>)
[![GitHub top language](<https://img.shields.io/github/languages/top/dogukanurker/flaskblog?style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)&link=https%3A%2F%2Fgithub.com%2Fsearch%3Fq%3Drepo%253ADogukanUrker%252FflaskBlog%2B%2Blanguage%253APython%26type%3Dcode>)](https://github.com/search?q=repo%3ADogukanUrker%2FflaskBlog++language%3APython&type=code)
![GitHub code size in bytes](<https://img.shields.io/github/languages/code-size/dogukanurker/flaskblog?style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)>)
![GitHub repo size](<https://img.shields.io/github/repo-size/dogukanurker/flaskblog?style=flat&labelColor=rgb(24%2024%2027)&color=rgb(244%2063%2094)>)

<img src="https://raw.githubusercontent.com/DogukanUrker/flaskBlog/main/images/GitHubBanner.png" style='border-radius: 0.5rem; widht:768px; height: 384px;' />

# [FlaskBlog](https://dogukanurker.com/flaskblog)

[English](../README.md) | **Türkçe**

Flask ile oluşturulmuş basit bir blog uygulaması.
<br/>
[İletişim](mailto:dogukanurker@icloud.com)<br/>
[Doğukan Ürker](https://dogukanurker.com)

### [Tanıtım Videosu 📺](https://youtu.be/BTBXe6yPbLE)

| [Desktop](https://github.com/DogukanUrker/flaskBlog/tree/master/images/desktop) | [Mobile](https://github.com/DogukanUrker/flaskBlog/tree/master/images/mobile) |
| :-----------------------------------------------------------------------------: | :---------------------------------------------------------------------------: |
|                    ![appDesktop](/images/desktop/light.png)                     |                    ![appMobile](/images/mobile/light.jpeg)                    |
|                     ![appDesktop](/images/desktop/dark.png)                     |                    ![appMobile](/images/mobile/dark.jpeg)                     |

[daha fazla görüntü için tıklayın📷](https://github.com/DogukanUrker/flaskBlog/tree/master/images)

## Özellikler 💫

| Özellik                    | Durum |
| :------------------------- | :---: |
| Kullanıcı Sayfası          |  ✅   |
| Kullanıcı Girişi           |  ✅   |
| Kullanıcı Puanları         |  ✅   |
| Kullanıcı Silme            |  ✅   |
| Kullanıcı Oturumu Kapat    |  ✅   |
| Kullanıcı Kaydı            |  ✅   |
| Kullanıcı Adı Değişikliği  |  ✅   |
| Kullanıcı Ayarları Sayfası |  ✅   |
| Kullanıcı Profil Resimleri |  ✅   |
| Yönetici Paneli            |  ✅   |
| Gösterge Tablosu Sayfası   |  ✅   |
| Şifre Sıfırlama            |  ✅   |
| Şifre Değiştirme           |  ✅   |
| Yaz Notları Editörü        |  ✅   |
| Arama Çubuğu               |  ✅   |
| Düzenleme Sonrası          |  ✅   |
| Gönderi Görüntüleme        |  ✅   |
| Gönderi Sil                |  ✅   |
| Gönderi Oluşturma          |  ✅   |
| Yorum                      |  ✅   |
| Yorum Sil                  |  ✅   |
| Günlük kaydı               |  ✅   |
| Hata Ayıklama Mesajları    |  ✅   |
| Veritabanı Denetleyicisi   |  ✅   |
| Koyu/Açık Temalar          |  ✅   |
| Duyarlı Tasarım            |  ✅   |
| Özel Profil Resmi          |  ✅   |
| Kullanıcı Doğrulama        |  ✅   |

## Gereksinimler 📦

- Flask
- Passlib
- WTForms
- Flask-WTF
- Python 3.10 veya daha yeni

## Diller 🧑🏻‍💻

### Backend

- Python

### Frontend

- HTML
- CSS
- JavaScript

## Kütüphaneler 📚

### Backend

- OS
- SSL
- Socket
- Smtplib
- Secrets
- SQLite3
- Time
- Random
- DateTime
- Email
- Passlib
- Flask
- WTForms
- Flask_WTF

### Frontend

- jQuery
- TailwindCSS
- Tabler Icons
- Summer Note

## Kurulum ⬇️

Github'dan kaynak kodu indirin 💾
`git clone https://github.com/DogukanUrker/flaskBlog.git`

dizine git 📁
`cd flaskBlog`

gereksinimleri yükle 🔽
`pip install -r requirements.txt`

çalışmaya hazır 🎉
`python app.py`
veya
`python desktop.py`
flaskBlog'u bir masaüstü uygulaması olarak çalıştır 💯

### Varsayılan Yönetici Hesabı

Kullanıcı adı: admin

Şifre: admin

### Katkıda Bulunanlar 💕

<a href="https://github.com/dogukanurker"><img src="https://avatars.githubusercontent.com/u/62756402" title="dogukanurker" width="80" height="80"></a>
<a href="https://github.com/adindrabkin"><img src="https://avatars.githubusercontent.com/u/47116975" title="adindrabkin" width="80" height="80"></a>
<a href="https://github.com/codehwang"><img src="https://avatars.githubusercontent.com/u/26578588" title="codehwang" width="80" height="80"></a>
<a href="https://github.com/dkashkarev"><img src="https://avatars.githubusercontent.com/u/67013355" title="dkashkarev" width="80" height="80"></a>

### Yıldızlar ⭐

[![Stargazers for @DogukanUrker/flaskBlog](http://bytecrank.com/nastyox/reporoster/php/stargazersSVG.php?theme=dark&user=DogukanUrker&repo=flaskBlog)](https://github.com/DogukanUrker/flaskBlog/stargazers)

### Forklar 🍴

[![Forkers for @DogukanUrker/flaskBlog](http://bytecrank.com/nastyox/reporoster/php/forkersSVG.php?theme=dark&user=DogukanUrker&repo=flaskBlog)](https://github.com/DogukanUrker/flaskBlog/network/members)

### Destek 💰

<a href="https://dogukanurker.com/donate" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/arial-red.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>

### Yıldız Çizelgesi ✨

[![Star History Chart](https://api.star-history.com/svg?repos=dogukanurker/flaskblog&type=Date)](https://star-history.com/#dogukanurker/flaskblog&Date)
