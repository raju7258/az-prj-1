# python-web-db
Example web application with database.  Python 3, MySQL.

# Setup
```
virtualenv -p `which python3` venv
source venv/bin/activate
pip install flask
pip install mysql-connector
```
